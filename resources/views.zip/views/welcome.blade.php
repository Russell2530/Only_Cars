@extends('layouts.app')
@section('title','Home')
@section('content')
<div class="container">
  <div class="py-4 text-center">
    <h1>OnlyCars</h1>
    <p>Komunitas otomotif (mobil) — event, galeri, merchandise</p>
  </div>

  <h3>Highlight Event</h3>
  <div class="row mb-4">
    @foreach($events as $e)
      <div class="col-md-4">
        <div class="card">
          @if($e->cover_image)
            <img src="{{ asset('storage/'.$e->cover_image) }}" class="card-img-top" style="height:200px;object-fit:cover;">
          @endif
          <div class="card-body">
            <h5 class="card-title">{{ $e->title }}</h5>
            <p class="card-text">{{ $e->location }} • {{ $e->date }}</p>
            <a href="{{ route('events.show',$e) }}" class="btn btn-sm btn-primary">Detail</a>
          </div>
        </div>
      </div>
    @endforeach
  </div>

  <h3>Galeri</h3>
  <div class="row mb-4">
    @foreach($gallery as $g)
      <div class="col-md-4 mb-3">
        <div class="card">
          @if($g->image_dokumentasi)
            <img src="{{ asset('storage/'.$g->image_dokumentasi) }}" class="card-img-top" style="height:180px;object-fit:cover;">
          @endif
          <div class="card-body">
            <p class="card-text">{{ $g->title }}</p>
          </div>
        </div>
      </div>
    @endforeach
  </div>

  <h3>Merchandise</h3>
  <div class="row mb-4">
    @foreach($merchandise as $m)
      <div class="col-md-4">
        <div class="card">
          @if($m->image_merch)
            <img src="{{ asset('storage/'.$m->image_merch) }}" class="card-img-top" style="height:200px;object-fit:cover;">
          @endif
          <div class="card-body">
            <h5 class="card-title">{{ $m->name }}</h5>
            <p class="card-text">Rp {{ number_format($m->price,0,',','.') }}</p>
            <a href="{{ route('merchandise.show',$m) }}" class="btn btn-sm btn-primary">Detail</a>
          </div>
        </div>
      </div>
    @endforeach
  </div>
</div>
@endsection
