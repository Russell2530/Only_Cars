@extends('layouts.app')
@section('title','Edit Event')
@section('content')
<div class="container">
    <h1>Edit Event</h1>
    <form action="{{ route('gallery.update',$gallery) }}" method="POST" enctype="multipart/form-data">
        @csrf @method('PUT')
        @include('gallery.form')
        <button class="btn btn-success">Update</button>
    </form>
</div>
@endsection
