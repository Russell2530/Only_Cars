@extends('layouts.app')
@section('title','Gallery')
@section('content')
<div class="container">
  <h1>Gallery</h1>
  <a href="{{ route('gallery.create') }}" class="btn btn-primary mb-3">Tambah Foto</a>

  <div class="row">
    @foreach($gallery as $g)
      <div class="col-md-4 mb-3">
        <div class="card">
          @if($g->image_dokumentasi)
            <img src="{{ asset('storage/'.$g->image_dokumentasi) }}" class="card-img-top" style="height:180px;object-fit:cover;">
          @endif
          <div class="card-body">
            <h5>{{ $g->title }}</h5>
            <a href="{{ route('gallery.edit',$g) }}" class="btn btn-warning btn-sm">Edit</a>
            <form action="{{ route('gallery.destroy',$g) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin hapus?')">
              @csrf @method('DELETE')
              <button class="btn btn-danger btn-sm">Hapus</button>
            </form>
          </div>
        </div>
      </div>
    @endforeach
  </div>

  {{ $gallery->links() }}
</div>
@endsection
