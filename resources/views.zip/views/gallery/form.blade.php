<div class="mb-3">
    <label>Judul</label>
    <input type="text" name="title" class="form-control" value="{{ old('title', $gallery->title ?? '') }}" required>
</div>
<div class="mb-3">
    <label>Cover Image</label>
    @if(!empty($gallery->cover_image))
        <div class="mb-2"><img src="{{ asset('storage/'.$gallery->cover_image) }}" width="150"></div>
    @endif
    <input type="file" name="image_dokumentasi" class="form-control" accept="image/*" {{ isset($gallery) ? '' : 'required' }}>
</div>
