@extends('layouts.app')

@section('content')
<div class="container">
    <h1>{{ $merchandise->name }}</h1>
    @if($merchandise->image_merch)
        <img src="{{ asset('storage/'.$merchandise->image_merch) }}" class="mb-3" style="max-width:300px;">
    @endif
    <p><strong>Harga:</strong> Rp {{ number_format($merchandise->price, 0, ',', '.') }}</p>
    <p>{{ $merchandise->description }}</p>
    <a href="{{ route('merchandise.index') }}" class="btn btn-secondary">Kembali</a>
</div>
@endsection
