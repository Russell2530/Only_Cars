@extends('layouts.app')
@section('title','Merchandise')
@section('content')
<div class="container">
  <h1>Merchandise</h1>
  <a href="{{ route('merchandise.create') }}" class="btn btn-primary mb-3">Tambah Merchandise</a>

  <div class="row">
    @foreach($merchandise as $m)
      <div class="col-md-4 mb-3">
        <div class="card">
          @if($m->image_merch)
            <img src="{{ asset('storage/'.$m->image_merch) }}" class="card-img-top" style="height:180px;object-fit:cover;">
          @endif
          <div class="card-body">
            <h5>{{ $m->name }}</h5>
            <p>Rp {{ number_format($m->price,0,',','.') }}</p>
            <a href="{{ route('merchandise.show',$m) }}" class="btn btn-info btn-sm">Detail</a>
            <a href="{{ route('merchandise.edit',$m) }}" class="btn btn-warning btn-sm">Edit</a>
            <form action="{{ route('merchandise.destroy',$m) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin hapus?')">
              @csrf @method('DELETE')
              <button class="btn btn-danger btn-sm">Hapus</button>
            </form>
          </div>
        </div>
      </div>
    @endforeach
  </div>

  {{ $merchandise->links() }}
</div>
@endsection
