@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Edit Merchandise</h1>
    <form action="{{ route('merchandise.update', $merchandise->id) }}" method="POST" enctype="multipart/form-data">
        @csrf @method('PUT')
        <div class="mb-3">
            <label>Nama Merchandise</label>
            <input type="text" name="name" value="{{ $merchandise->name }}" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Harga</label>
            <input type="number" name="price" value="{{ $merchandise->price }}" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Deskripsi</label>
            <textarea name="description" class="form-control">{{ $merchandise->description }}</textarea>
        </div>
        <div class="mb-3">
            <label>Gambar</label><br>
            @if($merchandise->image_merch)
                <img src="{{ asset('storage/'.$merchandise->image_merch) }}" width="150" class="mb-2">
            @endif
            <input type="file" name="image_merch" class="form-control">
        </div>
        <button class="btn btn-success">Update</button>
    </form>
</div>
@endsection
