@extends('layouts.app')
@section('title','Events')
@section('content')
<div class="container">
    <h1>Events</h1>
    <a href="{{ route('events.create') }}" class="btn btn-primary mb-3">+ Tambah Event</a>

    @if(session('success')) <div class="alert alert-success">{{ session('success') }}</div> @endif

    <div class="row">
        @foreach($events as $event)
            <div class="col-md-4 mb-3">
                <div class="card">
                    @if($event->cover_image)
                        <img src="{{ asset('storage/'.$event->cover_image) }}" class="card-img-top" style="height:180px;object-fit:cover;">
                    @endif
                    <div class="card-body">
                        <h5>{{ $event->title }}</h5>
                        <p>{{ $event->location }} • {{ $event->date }}</p>
                        <a href="{{ route('events.show', $event) }}" class="btn btn-info btn-sm">Detail</a>
                        <a href="{{ route('events.edit', $event) }}" class="btn btn-warning btn-sm">Edit</a>
                        <form action="{{ route('events.destroy', $event) }}" method="POST" class="d-inline" onsubmit="return confirm('Yakin hapus?')">
                            @csrf @method('DELETE')
                            <button class="btn btn-danger btn-sm">Hapus</button>
                        </form>
                    </div>
                </div>
            </div>
        @endforeach
    </div>

    {{ $events->links() }}
</div>
@endsection
