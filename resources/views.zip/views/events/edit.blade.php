@extends('layouts.app')
@section('title','Edit Event')
@section('content')
<div class="container">
    <h1>Edit Event</h1>
    <form action="{{ route('events.update',$event) }}" method="POST" enctype="multipart/form-data">
        @csrf @method('PUT')
        @include('events.form')
        <button class="btn btn-success">Update</button>
    </form>
</div>
@endsection
