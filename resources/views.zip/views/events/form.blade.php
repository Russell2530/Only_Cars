<div class="mb-3">
    <label>Judul</label>
    <input type="text" name="title" class="form-control" value="{{ old('title', $event->title ?? '') }}" required>
</div>

<div class="mb-3">
    <label>Tanggal</label>
    <input type="date" name="date" class="form-control" value="{{ old('date', $event->date ?? '') }}" required>
</div>

<div class="mb-3">
    <label>Lokasi</label>
    <input type="text" name="location" class="form-control" value="{{ old('location', $event->location ?? '') }}" required>
</div>

<div class="mb-3">
    <label>Deskripsi</label>
    <textarea name="description" class="form-control">{{ old('description', $event->description ?? '') }}</textarea>
</div>

<div class="mb-3">
    <label>Cover Image</label>
    @if(!empty($event->cover_image))
        <div class="mb-2"><img src="{{ asset('storage/'.$event->cover_image) }}" width="150"></div>
    @endif
    <input type="file" name="cover_image" class="form-control" accept="image/*" {{ isset($event) ? '' : 'required' }}>
</div>
