@extends('layouts.app')
@section('title','Tambah Event')
@section('content')
<div class="container">
    <h1>Tambah Event</h1>

    <form action="{{ route('events.store') }}" method="POST" enctype="multipart/form-data">
        @csrf
        @include('events.form')
        <button class="btn btn-primary">Simpan</button>
    </form>
</div>
@endsection
