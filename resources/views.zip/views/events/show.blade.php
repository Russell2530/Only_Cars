@extends('layouts.app')
@section('title', $event->title)
@section('content')
<div class="container">
    <h1>{{ $event->title }}</h1>
    @if($event->cover_image)
        <img src="{{ asset('storage/'.$event->cover_image) }}" class="img-fluid mb-3" style="max-height:500px;object-fit:cover;">
    @endif
    <p><strong>Tanggal:</strong> {{ $event->date }}</p>
    <p><strong>Lokasi:</strong> {{ $event->location }}</p>
    <p>{{ $event->description }}</p>
    <a href="{{ route('events.index') }}" class="btn btn-secondary">Kembali</a>
</div>
@endsection
